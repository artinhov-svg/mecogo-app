-- MeCOGO Database Schema
-- Run this in your Supabase SQL editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- USERS table
CREATE TABLE IF NOT EXISTS users (
    user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role VARCHAR(20) CHECK (role IN ('client', 'coach', 'admin')) NOT NULL DEFAULT 'client',
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    language_preference VARCHAR(10) DEFAULT 'en',
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- GOALS table
CREATE TABLE IF NOT EXISTS goals (
    goal_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_date DATE NOT NULL,
    end_date DATE,
    status VARCHAR(20) CHECK (status IN ('active', 'completed', 'archived')) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TASKS table (linked to goals)
CREATE TABLE IF NOT EXISTS tasks (
    task_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    goal_id UUID REFERENCES goals(goal_id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE,
    is_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- HABITS table (recurring)
CREATE TABLE IF NOT EXISTS habits (
    habit_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    frequency VARCHAR(20) CHECK (frequency IN ('daily', 'weekly', 'monthly')) NOT NULL,
    streak_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- PROGRESS_LOGS table (habit/task completion history)
CREATE TABLE IF NOT EXISTS progress_logs (
    log_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    habit_id UUID REFERENCES habits(habit_id) ON DELETE CASCADE,
    task_id UUID REFERENCES tasks(task_id) ON DELETE CASCADE,
    log_date DATE NOT NULL,
    status VARCHAR(20) CHECK (status IN ('completed', 'missed')) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ACCOUNTABILITY table (coach-client relations)
CREATE TABLE IF NOT EXISTS accountability (
    relation_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    coach_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    client_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(coach_id, client_id)
);

-- BADGES table (gamification)
CREATE TABLE IF NOT EXISTS badges (
    badge_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    earned_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SUBSCRIPTIONS table
CREATE TABLE IF NOT EXISTS subscriptions (
    sub_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id) ON DELETE CASCADE,
    plan VARCHAR(20) CHECK (plan IN ('free', 'pro', 'coach')) NOT NULL DEFAULT 'free',
    start_date DATE DEFAULT CURRENT_DATE,
    end_date DATE,
    status VARCHAR(20) CHECK (status IN ('active', 'expired')) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TRANSLATIONS table (multi-language content)
CREATE TABLE IF NOT EXISTS translations (
    trans_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(50) NOT NULL, -- 'goal', 'task', 'habit', 'ui'
    entity_id UUID,
    language VARCHAR(10) NOT NULL, -- 'en', 'fa'
    translated_text TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_goals_user_id ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_goal_id ON tasks(goal_id);
CREATE INDEX IF NOT EXISTS idx_habits_user_id ON habits(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_logs_user_id ON progress_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_logs_date ON progress_logs(log_date);
CREATE INDEX IF NOT EXISTS idx_accountability_coach ON accountability(coach_id);
CREATE INDEX IF NOT EXISTS idx_accountability_client ON accountability(client_id);
CREATE INDEX IF NOT EXISTS idx_translations_entity ON translations(entity_type, entity_id, language);

-- Row Level Security (RLS) Policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE habits ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE accountability ENABLE ROW LEVEL SECURITY;
ALTER TABLE badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE translations ENABLE ROW LEVEL SECURITY;

-- Users can only access their own data
CREATE POLICY "Users can access their own data" ON users 
    FOR ALL USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can access their own goals" ON goals 
    FOR ALL USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can access tasks from their goals" ON tasks 
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM goals 
            WHERE goals.goal_id = tasks.goal_id 
            AND goals.user_id::text = auth.uid()::text
        )
    );

CREATE POLICY "Users can access their own habits" ON habits 
    FOR ALL USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can access their own progress logs" ON progress_logs 
    FOR ALL USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can access their accountability relations" ON accountability 
    FOR ALL USING (
        auth.uid()::text = coach_id::text OR 
        auth.uid()::text = client_id::text
    );

CREATE POLICY "Users can access their own badges" ON badges 
    FOR ALL USING (auth.uid()::text = user_id::text);

CREATE POLICY "Users can access their own subscriptions" ON subscriptions 
    FOR ALL USING (auth.uid()::text = user_id::text);

-- Functions for automatic user creation on signup
CREATE OR REPLACE FUNCTION handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.users (user_id, email, name, language_preference)
    VALUES (
        NEW.id, 
        NEW.email, 
        COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'language', 'en')
    );
    
    -- Create default subscription
    INSERT INTO public.subscriptions (user_id, plan)
    VALUES (NEW.id, 'free');
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create user profile on signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION handle_new_user();
