import { useTranslation } from 'react-i18next';
import { useEffect } from 'react';

export const useLanguage = () => {
  const { i18n } = useTranslation();
  
  const isRTL = i18n.language === 'fa';
  
  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = i18n.language;
    
    // Update font family based on language
    if (isRTL) {
      document.documentElement.style.fontFamily = 'Vazirmatn, sans-serif';
    } else {
      document.documentElement.style.fontFamily = 'Inter, sans-serif';
    }
  }, [isRTL, i18n.language]);

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return { 
    currentLanguage: i18n.language, 
    isRTL, 
    changeLanguage 
  };
};
