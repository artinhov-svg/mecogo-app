import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Goal } from '../types';

export const exportGoalsToPDF = (goals: Goal[], userName: string, t: (key: string) => string) => {
  const doc = new jsPDF();

  // Set a standard font that is built into jsPDF to prevent loading errors.
  // This ensures stability, though it won't render Farsi characters correctly without font embedding.
  doc.setFont('Helvetica');

  // Add header
  doc.setFontSize(20);
  doc.text(`MeCOGO Goals Report for ${userName}`, 14, 22);
  doc.setFontSize(11);
  doc.setTextColor(100);
  doc.text(`Report generated on: ${new Date().toLocaleDateString()}`, 14, 30);

  // Define table columns
  const tableColumn = [t('goals.goalTitle'), t('goals.status'), t('goals.progress') + " (%)", t('goals.endDate')];
  const tableRows: (string | number)[][] = [];

  // Populate table rows
  goals.forEach(goal => {
    const goalData = [
      goal.title,
      t(`goals.${goal.status}`),
      goal.progress,
      goal.endDate ? goal.endDate.toLocaleDateString() : "N/A",
    ];
    tableRows.push(goalData);
  });

  // Add table to document
  (doc as any).autoTable({
    head: [tableColumn],
    body: tableRows,
    startY: 40,
    theme: 'grid',
    styles: { font: 'Helvetica' }, // Ensure table uses a safe, built-in font
    headStyles: { font: 'Helvetica', fontStyle: 'bold', fillColor: [2, 132, 199] },
  });

  // Save the PDF
  doc.save(`MeCOGO_Goals_${userName}.pdf`);
};

export const exportAnalyticsToPDF = (userName: string, t: (key: string) => string) => {
  const doc = new jsPDF();
  doc.setFont('Helvetica');
  doc.setFontSize(20);
  doc.text(`${t('analytics.title')} - ${userName}`, 14, 22);
  doc.setFontSize(12);
  doc.text(t('analytics.description'), 14, 30);
  // In a real app, you would add charts as images and more data here.
  doc.text("Analytics data and charts would be rendered here.", 14, 50);
  doc.save(`MeCOGO_Analytics_${userName}.pdf`);
};
