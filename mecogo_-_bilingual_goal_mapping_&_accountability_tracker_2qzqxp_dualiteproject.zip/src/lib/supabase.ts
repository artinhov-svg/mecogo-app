import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          user_id: string;
          role: 'client' | 'coach' | 'admin';
          name: string;
          email: string;
          password_hash: string;
          language_preference: string;
          created_at: string;
        };
        Insert: {
          user_id?: string;
          role: 'client' | 'coach' | 'admin';
          name: string;
          email: string;
          password_hash: string;
          language_preference?: string;
          created_at?: string;
        };
        Update: {
          user_id?: string;
          role?: 'client' | 'coach' | 'admin';
          name?: string;
          email?: string;
          password_hash?: string;
          language_preference?: string;
          created_at?: string;
        };
      };
      goals: {
        Row: {
          goal_id: string;
          user_id: string;
          title: string;
          description: string | null;
          start_date: string;
          end_date: string | null;
          status: 'active' | 'completed' | 'archived';
          created_at: string;
        };
        Insert: {
          goal_id?: string;
          user_id: string;
          title: string;
          description?: string | null;
          start_date: string;
          end_date?: string | null;
          status?: 'active' | 'completed' | 'archived';
          created_at?: string;
        };
        Update: {
          goal_id?: string;
          user_id?: string;
          title?: string;
          description?: string | null;
          start_date?: string;
          end_date?: string | null;
          status?: 'active' | 'completed' | 'archived';
          created_at?: string;
        };
      };
      tasks: {
        Row: {
          task_id: string;
          goal_id: string;
          title: string;
          description: string | null;
          due_date: string | null;
          is_completed: boolean;
          created_at: string;
        };
        Insert: {
          task_id?: string;
          goal_id: string;
          title: string;
          description?: string | null;
          due_date?: string | null;
          is_completed?: boolean;
          created_at?: string;
        };
        Update: {
          task_id?: string;
          goal_id?: string;
          title?: string;
          description?: string | null;
          due_date?: string | null;
          is_completed?: boolean;
          created_at?: string;
        };
      };
      habits: {
        Row: {
          habit_id: string;
          user_id: string;
          title: string;
          frequency: 'daily' | 'weekly' | 'monthly';
          streak_count: number;
          created_at: string;
        };
        Insert: {
          habit_id?: string;
          user_id: string;
          title: string;
          frequency: 'daily' | 'weekly' | 'monthly';
          streak_count?: number;
          created_at?: string;
        };
        Update: {
          habit_id?: string;
          user_id?: string;
          title?: string;
          frequency?: 'daily' | 'weekly' | 'monthly';
          streak_count?: number;
          created_at?: string;
        };
      };
    };
  };
};
