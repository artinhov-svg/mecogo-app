import React, { useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';

import './i18n';
import { useLanguage } from './hooks/useLanguage';
import { User, DashboardStats } from './types';
import { AppRouter } from './router';

import LoginForm from './components/auth/LoginForm';
import RegisterForm from './components/auth/RegisterForm';
import DemoBanner from './components/ui/DemoBanner';
import ImpersonationBanner from './components/ui/ImpersonationBanner';

function App() {
  const { isRTL } = useLanguage();
  const [user, setUser] = useState<User | null>(null);
  const [originalUser, setOriginalUser] = useState<User | null>(null); // For impersonation
  const [isAuthMode, setIsAuthMode] = useState('login'); // 'login' | 'register'

  const dashboardStats: DashboardStats = {
    activeGoals: 5,
    completedTasks: 12,
    habitStreak: 7,
    weeklyProgress: 78
  };

  const handleLogin = (email: string, password: string, role: User['role']) => {
    let loggedInUser: User | null = null;
    
    // Demo accounts
    const demoUsers = {
      'owner': { email: 'admin@mecogo.app', password: 'admin', name: 'Artin Hovsepian', id: 'owner-1', avatarUrl: `https://i.pravatar.cc/150?u=admin@mecogo.app` },
      'coach': { email: 'coach@mecogo.app', password: 'coach', name: 'Coach', id: 'coach-1', referralCode: 'COACH123', coachStatus: 'active', avatarUrl: `https://i.pravatar.cc/150?u=coach@mecogo.app` },
      'client': { email: 'client@mecogo.app', password: 'client', name: 'Client', id: 'client-1', avatarUrl: `https://i.pravatar.cc/150?u=client@mecogo.app`, isPro: true },
    };

    const demoUser = demoUsers[role as keyof typeof demoUsers];

    if (demoUser && email === demoUser.email && password === demoUser.password) {
      loggedInUser = {
        ...demoUser,
        role: role,
        language: 'en',
        createdAt: new Date(),
      } as User;
    } else {
      // Generic login for testing other accounts
      loggedInUser = {
        id: `user-${Date.now()}`,
        email,
        name: email.split('@')[0],
        role: role,
        language: 'en',
        createdAt: new Date(),
        avatarUrl: `https://i.pravatar.cc/150?u=${email}`,
        isPro: role === 'client' // make generic clients non-pro
      };
    }
    
    if (loggedInUser) {
      setUser(loggedInUser);
    } else {
      alert('Invalid credentials');
    }
  };

  const handleRegister = (name: string, email: string, password: string) => {
    setUser({
      id: '2',
      email,
      name,
      role: 'client',
      language: 'en',
      createdAt: new Date(),
      avatarUrl: `https://i.pravatar.cc/150?u=${email}`,
      isPro: false
    });
  };

  const handleLogout = () => {
    setUser(null);
    setOriginalUser(null);
    setIsAuthMode('login');
  };

  const handleImpersonate = (userToImpersonate: User) => {
    if (user && (user.role === 'owner' || user.role === 'coach')) {
      setOriginalUser(user);
      setUser(userToImpersonate);
    }
  };

  const handleStopImpersonating = () => {
    if (originalUser) {
      setUser(originalUser);
      setOriginalUser(null);
    }
  };

  const currentUser = user;

  return (
    <Router>
      <div className={`min-h-screen bg-gray-50 ${isRTL ? 'rtl font-vazir' : 'ltr font-inter'}`}>
        <DemoBanner />
        {originalUser && currentUser && (
          <ImpersonationBanner
            impersonatedUser={currentUser}
            onStopImpersonating={handleStopImpersonating}
          />
        )}
        <AnimatePresence mode="wait">
          {!currentUser ? (
            <div className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 flex items-center justify-center p-4">
              {isAuthMode === 'login' ? (
                <LoginForm
                  key="login"
                  onLogin={handleLogin}
                  onSwitchToRegister={() => setIsAuthMode('register')}
                />
              ) : (
                <RegisterForm
                  key="register"
                  onRegister={handleRegister}
                  onSwitchToLogin={() => setIsAuthMode('login')}
                />
              )}
            </div>
          ) : (
            <AppRouter 
              user={currentUser} 
              stats={dashboardStats} 
              onLogout={handleLogout}
              onImpersonate={handleImpersonate}
            />
          )}
        </AnimatePresence>
      </div>
    </Router>
  );
}

export default App;
