// Demo configuration for easy testing
export const DEMO_CONFIG = {
  // Enable demo mode (uses local mock data)
  DEMO_MODE: !import.meta.env.VITE_SUPABASE_URL || import.meta.env.VITE_SUPABASE_URL.includes('YOUR_'),
  
  // Demo user credentials
  DEMO_USER: {
    email: 'demo@mecogo.app',
    password: 'demo123',
    name: 'Demo User'
  },
  
  // Demo data settings
  AUTO_LOGIN_DEMO: true,
  SHOW_DEMO_BANNER: true,
  
  // Feature flags for demo
  FEATURES: {
    AUTH: true,
    GOALS: true,
    HABITS: true,
    ANALYTICS: true,
    MULTI_LANGUAGE: true,
    OFFLINE_MODE: true
  }
};

export const isDemoMode = () => DEMO_CONFIG.DEMO_MODE;
export const getDemoUser = () => DEMO_CONFIG.DEMO_USER;
