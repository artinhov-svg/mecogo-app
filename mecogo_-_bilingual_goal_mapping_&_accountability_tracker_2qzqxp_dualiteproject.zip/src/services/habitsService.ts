import { supabase } from '../lib/supabase';
import { Habit } from '../types';

export class HabitsService {
  async getHabits(userId: string): Promise<Habit[]> {
    const { data, error } = await supabase
      .from('habits')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data.map(habit => ({
      id: habit.habit_id,
      userId: habit.user_id,
      title: habit.title,
      frequency: habit.frequency,
      streakCount: habit.streak_count,
      createdAt: new Date(habit.created_at)
    }));
  }

  async createHabit(habit: Omit<Habit, 'id' | 'streakCount' | 'createdAt'>) {
    const { data, error } = await supabase
      .from('habits')
      .insert({
        user_id: habit.userId,
        title: habit.title,
        frequency: habit.frequency
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async updateHabit(habitId: string, updates: Partial<Habit>) {
    const { data, error } = await supabase
      .from('habits')
      .update({
        title: updates.title,
        frequency: updates.frequency,
        streak_count: updates.streakCount
      })
      .eq('habit_id', habitId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async deleteHabit(habitId: string) {
    const { error } = await supabase
      .from('habits')
      .delete()
      .eq('habit_id', habitId);

    if (error) throw error;
  }

  async markHabitComplete(habitId: string, userId: string) {
    // Log the completion
    const { error: logError } = await supabase
      .from('progress_logs')
      .insert({
        user_id: userId,
        habit_id: habitId,
        log_date: new Date().toISOString().split('T')[0],
        status: 'completed'
      });

    if (logError) throw logError;

    // Update streak count
    const { data: habit } = await supabase
      .from('habits')
      .select('streak_count')
      .eq('habit_id', habitId)
      .single();

    if (habit) {
      const { error: updateError } = await supabase
        .from('habits')
        .update({ streak_count: habit.streak_count + 1 })
        .eq('habit_id', habitId);

      if (updateError) throw updateError;
    }
  }
}

export const habitsService = new HabitsService();
