import { supabase } from '../lib/supabase';
import { Goal } from '../types';

export class GoalsService {
  async getGoals(userId: string): Promise<Goal[]> {
    const { data, error } = await supabase
      .from('goals')
      .select(`
        *,
        tasks (*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data.map(goal => ({
      id: goal.goal_id,
      userId: goal.user_id,
      title: goal.title,
      description: goal.description,
      startDate: new Date(goal.start_date),
      endDate: goal.end_date ? new Date(goal.end_date) : undefined,
      status: goal.status,
      progress: this.calculateProgress(goal.tasks),
      tasks: goal.tasks.map((task: any) => ({
        id: task.task_id,
        goalId: task.goal_id,
        title: task.title,
        description: task.description,
        dueDate: task.due_date ? new Date(task.due_date) : undefined,
        isCompleted: task.is_completed,
        createdAt: new Date(task.created_at)
      })),
      createdAt: new Date(goal.created_at)
    }));
  }

  async createGoal(goal: Omit<Goal, 'id' | 'progress' | 'tasks' | 'createdAt'>) {
    const { data, error } = await supabase
      .from('goals')
      .insert({
        user_id: goal.userId,
        title: goal.title,
        description: goal.description,
        start_date: goal.startDate.toISOString().split('T')[0],
        end_date: goal.endDate?.toISOString().split('T')[0],
        status: goal.status
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async updateGoal(goalId: string, updates: Partial<Goal>) {
    const { data, error } = await supabase
      .from('goals')
      .update({
        title: updates.title,
        description: updates.description,
        start_date: updates.startDate?.toISOString().split('T')[0],
        end_date: updates.endDate?.toISOString().split('T')[0],
        status: updates.status
      })
      .eq('goal_id', goalId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async deleteGoal(goalId: string) {
    const { error } = await supabase
      .from('goals')
      .delete()
      .eq('goal_id', goalId);

    if (error) throw error;
  }

  private calculateProgress(tasks: any[]): number {
    if (!tasks || tasks.length === 0) return 0;
    const completedTasks = tasks.filter(task => task.is_completed).length;
    return Math.round((completedTasks / tasks.length) * 100);
  }
}

export const goalsService = new GoalsService();
