import { supabase } from '../lib/supabase';
import { User } from '../types';

export class AuthService {
  async signUp(email: string, password: string, name: string, language = 'en') {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          language
        }
      }
    });

    if (error) throw error;
    return data;
  }

  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;
    return data;
  }

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }

  async getCurrentUser(): Promise<User | null> {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) return null;

    const { data: profile } = await supabase
      .from('users')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (!profile) return null;

    return {
      id: profile.user_id,
      email: profile.email,
      name: profile.name,
      role: profile.role,
      language: profile.language_preference as 'en' | 'fa',
      avatarUrl: profile.avatar_url,
      createdAt: new Date(profile.created_at)
    };
  }

  onAuthStateChange(callback: (user: User | null) => void) {
    return supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        const user = await this.getCurrentUser();
        callback(user);
      } else {
        callback(null);
      }
    });
  }
}

export const authService = new AuthService();
