import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { faker } from '@faker-js/faker';
import { Goal, User } from '../../types';
import Checklist from '../pro/Checklist';
import ProFeatureBadge from '../ui/ProFeatureBadge';
import UpgradeModal from '../pro/UpgradeModal';
import { Target, Calendar, BarChart, Tag, Trash2, Edit, Lock, Info, MessageSquare } from 'lucide-react';

interface GoalDetailProps {
  user: User;
}

const GoalDetail: React.FC<GoalDetailProps> = ({ user }) => {
    const { id } = useParams();
    const { t } = useTranslation();
    const navigate = useNavigate();
    const [isUpgradeModalOpen, setUpgradeModalOpen] = useState(false);

    // Mock data for a single goal
    const mockGoal: Goal = {
        id: id || '1',
        userId: '1',
        title: faker.lorem.sentence(4),
        description: faker.lorem.paragraphs(2),
        startDate: faker.date.past(),
        endDate: faker.date.future(),
        status: 'active',
        progress: faker.number.int({ min: 20, max: 80 }),
        tasks: [],
        checklist: Array.from({ length: 5 }, (_, i) => ({
            id: `cl-${i}`,
            text: faker.lorem.sentence(5),
            isCompleted: faker.datatype.boolean()
        })),
        isBusinessGoal: true,
        kpis: ['Increase MRR by 15%', 'Reduce churn by 5%'],
        createdAt: faker.date.past(),
        createdBy: 'coach', // Example of a coach-created goal
    };

    const isDeletable = mockGoal.createdBy === 'user';

    const handleChatClick = () => {
        if (user.isPro) {
            navigate(`/chat/${mockGoal.id}`);
        } else {
            setUpgradeModalOpen(true);
        }
    };

    return (
        <>
            <div className="p-6">
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
                    <div className="flex items-start justify-between mb-6">
                        <div className="flex items-center space-x-4 rtl:space-x-reverse">
                            <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                                <Target className="w-8 h-8 text-primary-600" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold text-gray-900">{mockGoal.title}</h1>
                                <div className="flex items-center space-x-4 rtl:space-x-reverse text-sm text-gray-500 mt-2">
                                    <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                        <Calendar className="w-4 h-4" />
                                        <span>{t('goals.endDate')}: {mockGoal.endDate?.toLocaleDateString()}</span>
                                    </div>
                                    <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                        <BarChart className="w-4 h-4" />
                                        <span>{mockGoal.progress}% {t('goals.progress')}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <button className="p-2 text-gray-500 hover:text-blue-600 rounded-lg hover:bg-blue-50">
                                <Edit className="w-5 h-5" />
                            </button>
                            {isDeletable ? (
                                <button className="p-2 text-gray-500 hover:text-red-600 rounded-lg hover:bg-red-50">
                                    <Trash2 className="w-5 h-5" />
                                </button>
                            ) : (
                                <button className="p-2 text-gray-400 cursor-not-allowed" title={t('goals.createdByCoach') as string}>
                                    <Lock className="w-5 h-5" />
                                </button>
                            )}
                        </div>
                    </div>

                    {!isDeletable && (
                        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 text-blue-800 text-sm mb-6 flex items-center space-x-3 rtl:space-x-reverse">
                            <Info className="w-5 h-5 flex-shrink-0" />
                            <p>{t('goals.createdByCoach')}</p>
                        </div>
                    )}

                    <p className="text-gray-700 mb-8">{mockGoal.description}</p>

                    {mockGoal.isBusinessGoal && mockGoal.kpis && (
                        <div className="mb-8">
                            <h3 className="text-lg font-semibold text-gray-800 mb-3">{t('goals.kpis')}</h3>
                            <div className="flex flex-wrap gap-2">
                                {mockGoal.kpis.map((kpi, index) => (
                                    <div key={index} className="flex items-center bg-blue-50 text-blue-700 text-sm font-medium px-3 py-1 rounded-full">
                                        <Tag className="w-4 h-4 mr-2 rtl:ml-2" />
                                        {kpi}
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    {mockGoal.checklist && <Checklist initialItems={mockGoal.checklist} />}

                    <div className="mt-8 pt-6 border-t">
                        <button 
                            onClick={handleChatClick}
                            className="inline-flex items-center space-x-2 rtl:space-x-reverse bg-secondary-500 text-white px-4 py-2 rounded-lg hover:bg-secondary-600"
                        >
                            <MessageSquare className="w-5 h-5" />
                            <span>{t('goals.joinGroupChat')}</span>
                            {!user.isPro && <ProFeatureBadge />}
                        </button>
                    </div>
                </div>
            </div>
            <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setUpgradeModalOpen(false)} />
        </>
    );
};

export default GoalDetail;
