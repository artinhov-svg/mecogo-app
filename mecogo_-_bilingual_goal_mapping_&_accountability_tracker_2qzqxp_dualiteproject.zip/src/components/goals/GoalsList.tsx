import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Plus, Target, Calendar, MoreVertical, Briefcase, Lock, FileDown } from 'lucide-react';
import { Goal, User } from '../../types';
import { faker } from '@faker-js/faker';
import { Link } from 'react-router-dom';
import ProFeatureBadge from '../ui/ProFeatureBadge';
import UpgradeModal from '../pro/UpgradeModal';
import { exportGoalsToPDF } from '../../utils/pdfExporter';

interface GoalsListProps {
  user: User;
}

const GoalsList: React.FC<GoalsListProps> = ({ user }) => {
  const { t } = useTranslation();
  const [isUpgradeModalOpen, setUpgradeModalOpen] = useState(false);

  const goals: Goal[] = Array.from({ length: 4 }, (_, i) => ({
    id: `goal-${i}`,
    userId: 'user-1',
    title: faker.lorem.words(i % 2 === 0 ? 3 : 5),
    description: faker.lorem.sentence(),
    startDate: faker.date.past(),
    endDate: faker.date.future(),
    status: faker.helpers.arrayElement(['active', 'completed']),
    progress: faker.number.int({ min: 0, max: 100 }),
    tasks: [],
    isBusinessGoal: i % 2 === 0,
    createdAt: faker.date.past(),
    createdBy: i === 1 ? 'coach' : 'user',
  }));

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  const handleExportClick = () => {
    if (user.isPro) {
      exportGoalsToPDF(goals, user.name, t);
    } else {
      setUpgradeModalOpen(true);
    }
  };

  return (
    <>
      <div className="p-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t('goals.myGoals')}</h1>
              <p className="text-gray-500 mt-1">{t('goals.trackManageCelebrate')}</p>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse mt-4 sm:mt-0">
              <button 
                onClick={handleExportClick}
                className="flex items-center space-x-2 rtl:space-x-reverse bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200"
              >
                <FileDown className="w-4 h-4" />
                <span>{t('goals.exportToPdf')}</span>
                {!user.isPro && <ProFeatureBadge />}
              </button>
              <button className="flex items-center space-x-2 rtl:space-x-reverse bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700">
                <Plus className="w-4 h-4" />
                <span>{t('goals.createGoal')}</span>
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal, index) => (
            <motion.div
              key={goal.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 flex flex-col"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${goal.isBusinessGoal ? 'bg-secondary-100' : 'bg-primary-100'}`}>
                    {goal.isBusinessGoal ? <Briefcase className="w-5 h-5 text-secondary-600" /> : <Target className="w-5 h-5 text-primary-600" />}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 truncate">{goal.title}</h3>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <span className={`inline-block px-2 py-1 text-xs rounded-full ${getStatusColor(goal.status)}`}>
                        {t(`goals.${goal.status}`)}
                      </span>
                      {goal.createdBy === 'coach' && (
                        <div className="flex items-center text-xs text-gray-500" title={t('goals.createdByCoach') as string}>
                          <Lock className="w-3 h-3 mr-1 rtl:ml-1" />
                          <span>Coach</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <button className="p-1 text-gray-400 hover:text-gray-600"><MoreVertical className="w-4 h-4" /></button>
              </div>
              
              <div className="flex-grow">
                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                    <span>{t('goals.progress')}</span>
                    <span>{goal.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full" style={{ width: `${goal.progress}%` }} />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm text-gray-500">
                {goal.endDate && (
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <Calendar className="w-4 h-4" />
                    <span>{goal.endDate.toLocaleDateString()}</span>
                  </div>
                )}
                <Link to={`/goals/${goal.id}`} className="font-medium text-primary-600 hover:text-primary-700">
                  {t('goals.viewDetails')}
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
      <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setUpgradeModalOpen(false)} />
    </>
  );
};

export default GoalsList;
