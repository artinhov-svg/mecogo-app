import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { User } from '../../types';
import { useTranslation } from 'react-i18next';
import { LogOut, LayoutDashboard, Ticket, Settings, Gem, Users, Share2, Database, SlidersHorizontal } from 'lucide-react';
import LanguageSwitcher from '../ui/LanguageSwitcher';
import { ViralLogo } from '../ui/Logo';

interface AdminLayoutProps {
  user: User;
  onLogout: () => void;
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ user, onLogout, children }) => {
  const { t } = useTranslation();
  const location = useLocation();

  const menuItems = [
    { to: '/admin', label: t('admin.dashboard'), icon: LayoutDashboard },
    { to: '/admin/users', label: t('admin.users'), icon: Users },
    { to: '/admin/discounts', label: t('admin.discounts'), icon: Ticket },
    { to: '/admin/referrals', label: t('admin.referrals'), icon: Share2 },
    { to: '/admin/financial-settings', label: t('admin.financialSettings'), icon: Gem },
    { to: '/admin/management', label: t('admin.platformManagement'), icon: Database },
    { to: '/admin/settings', label: t('admin.appearanceSettings'), icon: SlidersHorizontal },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-gray-800 text-white flex flex-col">
        <div className="flex items-center justify-center h-20 border-b border-gray-700 space-x-3 px-4">
          <ViralLogo size="sm" />
          <h1 className="text-xl font-bold">MeCOGO</h1>
        </div>
        <nav className="flex-grow p-4 space-y-2">
          {menuItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/admin'}
              className={({ isActive }) =>
                `flex items-center space-x-3 rtl:space-x-reverse px-3 py-2 rounded-lg transition-colors ${
                  isActive ? 'bg-primary-600 text-white' : 'hover:bg-gray-700'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-700">
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <img src={user.avatarUrl} alt={user.name} className="w-10 h-10 rounded-full" />
                <div>
                    <p className="font-semibold">{user.name}</p>
                    <p className="text-sm text-gray-400">{t('admin.adminPanel')}</p>
                </div>
            </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow-md h-20 flex items-center justify-between px-8">
          <h2 className="text-xl font-semibold text-gray-700">
            {menuItems.find(item => location.pathname.startsWith(item.to))?.label || t('admin.dashboard')}
          </h2>
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <LanguageSwitcher />
            <button onClick={onLogout} className="flex items-center space-x-2 rtl:space-x-reverse text-gray-600 hover:text-red-500">
              <LogOut className="w-5 h-5" />
              <span>{t('nav.logout')}</span>
            </button>
          </div>
        </header>
        <main className="flex-1 p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
