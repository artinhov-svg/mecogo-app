import React from 'react';
import { useTranslation } from 'react-i18next';
import { faker } from '@faker-js/faker';
import { User } from '../../types';
import { Eye } from 'lucide-react';

interface AccountViewerProps {
    onImpersonate: (user: User) => void;
}

const AccountViewer: React.FC<AccountViewerProps> = ({ onImpersonate }) => {
    const { t } = useTranslation();
    const users: User[] = Array.from({ length: 15 }, (_, i) => ({
        id: faker.string.uuid(),
        name: faker.person.fullName(),
        email: faker.internet.email(),
        role: faker.helpers.arrayElement(['client', 'coach']),
        createdAt: faker.date.past(),
        avatarUrl: `https://i.pravatar.cc/150?u=user${i}`,
        language: 'en'
    }));

    return (
        <div className="bg-white p-8 rounded-lg shadow">
            <h2 className="text-2xl font-bold mb-6">{t('admin.users')}</h2>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead>
                        <tr className="border-b">
                            <th className="py-2">Name</th>
                            <th className="py-2">Email</th>
                            <th className="py-2">Role</th>
                            <th className="py-2">Joined</th>
                            <th className="py-2 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id} className="border-b hover:bg-gray-50">
                                <td className="py-3 flex items-center space-x-3">
                                    <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full" />
                                    <span>{user.name}</span>
                                </td>
                                <td className="py-3">{user.email}</td>
                                <td className="py-3">
                                    <span className={`capitalize px-2 py-1 text-xs font-medium rounded-full ${user.role === 'coach' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                                        {user.role}
                                    </span>
                                </td>
                                <td className="py-3 text-sm text-gray-600">{user.createdAt.toLocaleDateString()}</td>
                                <td className="py-3 text-center">
                                    <button 
                                        onClick={() => onImpersonate(user)}
                                        className="p-2 text-gray-500 hover:text-primary-600 rounded-full hover:bg-primary-50 transition-colors"
                                        title={t('admin.viewAsUser') as string}
                                    >
                                        <Eye className="w-5 h-5" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AccountViewer;
