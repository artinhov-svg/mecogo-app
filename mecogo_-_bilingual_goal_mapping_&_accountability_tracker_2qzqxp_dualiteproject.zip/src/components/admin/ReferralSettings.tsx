import React from 'react';
import { useTranslation } from 'react-i18next';
import { faker } from '@faker-js/faker';
import { Referral } from '../../types';
import { DollarSign } from 'lucide-react';

const ReferralSettings: React.FC = () => {
    const { t } = useTranslation();
    const commissionRate = 15; // Mock commission rate

    const referrals: Referral[] = Array.from({ length: 10 }, () => {
        const commission = faker.number.float({ min: 5, max: 50, precision: 0.01 });
        return {
            id: faker.string.uuid(),
            referrerName: faker.person.fullName(),
            referrerId: faker.string.uuid(),
            referredUserName: faker.person.fullName(),
            referredUserId: faker.string.uuid(),
            date: faker.date.past(),
            status: faker.helpers.arrayElement(['completed', 'pending']),
            commissionEarned: commission,
        };
    });

    return (
        <div className="space-y-8">
            <div className="bg-white p-8 rounded-lg shadow">
                <h2 className="text-2xl font-bold mb-2">{t('admin.referrals')}</h2>
                <p className="text-gray-600 mb-6">Manage and view all coach referral activities.</p>

                <div className="bg-primary-50 border-l-4 border-primary-500 p-4 rounded-r-lg mb-8">
                    <div className="flex items-center">
                        <DollarSign className="w-6 h-6 text-primary-700 mr-3" />
                        <div>
                            <p className="font-semibold text-primary-800">{t('admin.coachCommissionRate')}</p>
                            <p className="text-2xl font-bold text-primary-900">{commissionRate}%</p>
                            <p className="text-xs text-primary-700">This setting is managed in Financial Settings.</p>
                        </div>
                    </div>
                </div>

                <h3 className="text-xl font-semibold mb-4">{t('admin.referralHistory')}</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50">
                            <tr className="border-b">
                                <th className="p-3 font-semibold">{t('admin.referrer')}</th>
                                <th className="p-3 font-semibold">{t('admin.referredUser')}</th>
                                <th className="p-3 font-semibold">{t('admin.date')}</th>
                                <th className="p-3 font-semibold">{t('common.status')}</th>
                                <th className="p-3 font-semibold text-right">{t('admin.commission')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {referrals.map(ref => (
                                <tr key={ref.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3">{ref.referrerName}</td>
                                    <td className="p-3">{ref.referredUserName}</td>
                                    <td className="p-3 text-sm text-gray-600">{ref.date.toLocaleDateString()}</td>
                                    <td className="p-3">
                                        <span className={`capitalize px-2 py-1 text-xs font-medium rounded-full ${ref.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                            {ref.status}
                                        </span>
                                    </td>
                                    <td className="p-3 text-right font-medium text-green-600">
                                        ${ref.commissionEarned.toFixed(2)}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ReferralSettings;
