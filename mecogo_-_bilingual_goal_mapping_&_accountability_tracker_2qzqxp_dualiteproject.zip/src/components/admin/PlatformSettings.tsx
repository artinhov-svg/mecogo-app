import React from 'react';
import { useTranslation } from 'react-i18next';
import { Upload } from 'lucide-react';

const PlatformSettings: React.FC = () => {
    const { t } = useTranslation();
    return (
        <div className="bg-white p-8 rounded-lg shadow max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">{t('admin.appearanceSettings')}</h2>
            <div className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">{t('admin.uploadLogo')}</label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                        <div className="space-y-1 text-center">
                            <Upload className="mx-auto h-12 w-12 text-gray-400" />
                            <div className="flex text-sm text-gray-600">
                                <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500">
                                    <span>Upload a file</span>
                                    <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                                </label>
                                <p className="pl-1">or drag and drop</p>
                            </div>
                            <p className="text-xs text-gray-500">PNG, JPG, SVG up to 1MB</p>
                        </div>
                    </div>
                </div>
                 <button className="w-full bg-primary-600 text-white py-2 rounded-lg">{t('common.save')}</button>
            </div>
        </div>
    );
};

export default PlatformSettings;
