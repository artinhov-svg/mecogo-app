import React from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, Edit, Trash2 } from 'lucide-react';

const DiscountCodeManager: React.FC = () => {
    const { t } = useTranslation();
    const codes = [
        { id: 1, code: 'SUMMER25', percentage: 25, active: true },
        { id: 2, code: 'WELCOME10', percentage: 10, active: true },
        { id: 3, code: 'EXPIRED50', percentage: 50, active: false },
    ];

    return (
        <div className="bg-white p-8 rounded-lg shadow">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">{t('admin.discounts')}</h2>
                <button className="bg-primary-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>{t('admin.createDiscount')}</span>
                </button>
            </div>
            <table className="w-full text-left">
                <thead>
                    <tr className="border-b">
                        <th className="py-2">{t('admin.code')}</th>
                        <th className="py-2">{t('admin.percentage')}</th>
                        <th className="py-2">{t('admin.active')}</th>
                        <th className="py-2">{t('admin.actions')}</th>
                    </tr>
                </thead>
                <tbody>
                    {codes.map(c => (
                        <tr key={c.id} className="border-b">
                            <td className="py-4 font-mono">{c.code}</td>
                            <td className="py-4">{c.percentage}%</td>
                            <td className="py-4">
                                <span className={`px-2 py-1 text-xs rounded-full ${c.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                                    {c.active ? 'Active' : 'Inactive'}
                                </span>
                            </td>
                            <td className="py-4 flex space-x-2">
                                <button className="text-gray-500 hover:text-blue-600"><Edit className="w-4 h-4" /></button>
                                <button className="text-gray-500 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default DiscountCodeManager;
