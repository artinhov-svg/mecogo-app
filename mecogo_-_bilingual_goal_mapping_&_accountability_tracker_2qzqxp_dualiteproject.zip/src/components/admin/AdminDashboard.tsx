import React from 'react';

const AdminDashboard: React.FC = () => {
    // Mock data
    const stats = [
        { label: 'Total Users', value: '1,257' },
        { label: 'Active Subscriptions', value: '488' },
        { label: 'Monthly Revenue', value: '$12,450' },
        { label: 'Active Coaches', value: '76' }
    ];

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-8">Admin Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {stats.map(stat => (
                    <div key={stat.label} className="bg-white p-6 rounded-lg shadow">
                        <p className="text-sm text-gray-500">{stat.label}</p>
                        <p className="text-3xl font-bold text-gray-800 mt-2">{stat.value}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AdminDashboard;
