import React from 'react';
import { useTranslation } from 'react-i18next';
import { Download, FileOutput, Key, SlidersHorizontal, Code, BrainCircuit, Wallet, Briefcase, FileDown, MessageSquare } from 'lucide-react';

const Card: React.FC<{ title: string; icon: React.ElementType; children: React.ReactNode }> = ({ title, icon: Icon, children }) => (
    <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex items-center mb-4">
            <Icon className="w-6 h-6 text-primary-600 mr-3 rtl:ml-3" />
            <h3 className="text-xl font-bold text-gray-800">{title}</h3>
        </div>
        <div>{children}</div>
    </div>
);

const PlatformManagement: React.FC = () => {
    const { t } = useTranslation();
    const [bannerHtml, setBannerHtml] = React.useState('<div class="bg-green-500 text-white text-center p-2">Special Offer!</div>');

    const features = [
        { id: 'ai_analysis', name: t('admin.aiAnalysis'), icon: BrainCircuit },
        { id: 'crypto_wallet', name: t('admin.cryptoWallet'), icon: Wallet },
        { id: 'business_goals', name: t('admin.businessGoals'), icon: Briefcase },
        { id: 'pdf_export', name: t('admin.pdfExport'), icon: FileDown },
        { id: 'group_chat', name: t('admin.groupChat'), icon: MessageSquare },
    ];

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-gray-800">{t('admin.platformManagement')}</h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Data Management */}
                <div className="space-y-8">
                    <Card title={t('admin.dataBackup')} icon={Download}>
                        <p className="text-gray-600 mb-4">Download a full backup of the database.</p>
                        <button className="w-full bg-blue-600 text-white py-2 rounded-lg flex items-center justify-center space-x-2 rtl:space-x-reverse">
                            <Download className="w-4 h-4" />
                            <span>{t('admin.downloadBackup')}</span>
                        </button>
                    </Card>
                    <Card title={t('admin.dataExport')} icon={FileOutput}>
                        <p className="text-gray-600 mb-4">Export user data to an Excel file.</p>
                        <button className="w-full bg-green-600 text-white py-2 rounded-lg flex items-center justify-center space-x-2 rtl:space-x-reverse">
                            <FileOutput className="w-4 h-4" />
                            <span>{t('admin.exportUsersToExcel')}</span>
                        </button>
                        <p className="text-xs text-red-600 mt-3 rtl:text-right">{t('admin.exportWarning')}</p>
                    </Card>
                </div>

                {/* Settings */}
                <div className="space-y-8">
                    <Card title={t('admin.paymentGateways')} icon={Key}>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 rtl:text-right">{t('admin.stripeApiKey')}</label>
                                <input type="password" placeholder="sk_test_..." className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3" />
                            </div>
                            <button className="w-full bg-primary-600 text-white py-2 rounded-lg">{t('common.save')}</button>
                        </div>
                    </Card>
                    <Card title={t('admin.premiumFeatures')} icon={SlidersHorizontal}>
                        <div className="space-y-3">
                            {features.map(feature => (
                                <div key={feature.id} className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <feature.icon className="w-4 h-4 text-gray-500 mr-2 rtl:ml-2" />
                                        <span className="font-medium text-gray-700">{feature.name}</span>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" defaultChecked className="sr-only peer" />
                                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-primary-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] rtl:after:right-[2px] rtl:after:left-auto after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                                    </label>
                                </div>
                            ))}
                        </div>
                    </Card>
                </div>

                {/* Sponsor Banners */}
                <div className="lg:col-span-2">
                    <Card title={t('admin.sponsorBanners')} icon={Code}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2 rtl:text-right">{t('admin.bannerHtml')}</label>
                                <textarea 
                                    value={bannerHtml}
                                    onChange={(e) => setBannerHtml(e.target.value)}
                                    rows={5}
                                    className="w-full font-mono text-sm p-2 border border-gray-300 rounded-md"
                                ></textarea>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2 rtl:text-right">{t('admin.preview')}</label>
                                <div className="border rounded-md p-4 h-full" dangerouslySetInnerHTML={{ __html: bannerHtml }}></div>
                            </div>
                        </div>
                         <button className="w-full bg-primary-600 text-white py-2 rounded-lg mt-4">{t('common.save')}</button>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default PlatformManagement;
