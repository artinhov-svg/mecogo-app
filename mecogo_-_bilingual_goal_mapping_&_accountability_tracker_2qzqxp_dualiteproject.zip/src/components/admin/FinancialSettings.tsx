import React from 'react';
import { useTranslation } from 'react-i18next';

const FinancialSettings: React.FC = () => {
    const { t } = useTranslation();
    return (
        <div className="bg-white p-8 rounded-lg shadow max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">{t('admin.financialSettings')}</h2>
            <div className="space-y-8">
                {/* Crypto Settings */}
                <div className="space-y-6">
                    <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Crypto & Penalty</h3>
                    <div>
                        <label htmlFor="penaltyFee" className="block text-sm font-medium text-gray-700">{t('admin.penaltyFee')}</label>
                        <div className="mt-1 relative rounded-md shadow-sm">
                            <input type="number" name="penaltyFee" id="penaltyFee" className="block w-full pl-7 pr-12 border-gray-300 rounded-md" placeholder="5" />
                            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                <span className="text-gray-500 sm:text-sm">%</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="ownerWallet" className="block text-sm font-medium text-gray-700">{t('admin.ownerWallet')}</label>
                        <input type="text" name="ownerWallet" id="ownerWallet" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3" placeholder="0x..." />
                    </div>
                </div>

                {/* Commission Settings */}
                <div className="space-y-6">
                    <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Commissions</h3>
                     <div>
                        <label htmlFor="coachCommission" className="block text-sm font-medium text-gray-700">{t('admin.coachCommissionRate')}</label>
                        <div className="mt-1 relative rounded-md shadow-sm">
                            <input type="number" name="coachCommission" id="coachCommission" className="block w-full pl-7 pr-12 border-gray-300 rounded-md" placeholder="10" />
                            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                <span className="text-gray-500 sm:text-sm">%</span>
                            </div>
                        </div>
                         <p className="mt-2 text-xs text-gray-500">This is the global commission rate for all coaches who refer new clients.</p>
                    </div>
                </div>

                <button className="w-full bg-primary-600 text-white py-2 rounded-lg mt-4">{t('common.save')}</button>
            </div>
        </div>
    );
};

export default FinancialSettings;
