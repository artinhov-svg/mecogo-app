import React from 'react';
import { useTranslation } from 'react-i18next';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Target, 
  Repeat, 
  BarChart3, 
  Users, 
  User as UserIcon,
  Briefcase
} from 'lucide-react';
import { User } from '../../types';

interface SidebarProps {
  user: User;
}

const Sidebar: React.FC<SidebarProps> = ({ user }) => {
  const { t } = useTranslation();

  const commonItems = [
    { to: '/', label: t('nav.dashboard'), icon: LayoutDashboard },
    { to: '/goals', label: t('nav.goals'), icon: Target },
    { to: '/habits', label: t('nav.habits'), icon: Repeat },
    { to: '/analytics', label: t('nav.analytics'), icon: BarChart3 },
    { to: '/accountability', label: t('nav.accountability'), icon: Users },
    { to: '/profile', label: t('nav.profile'), icon: UserIcon },
  ];

  const coachItems = [
    { to: '/coach/dashboard', label: t('nav.coachDashboard'), icon: Briefcase },
  ];

  const menuItems = user.role === 'coach' ? [...commonItems, ...coachItems] : commonItems;

  return (
    <div className="w-64 bg-white shadow-sm border-r border-gray-200 h-screen flex flex-col">
      <div className="p-6 flex-grow">
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `w-full flex items-center space-x-3 rtl:space-x-reverse px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-primary-50 text-primary-700 border border-primary-200'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`
                }
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
