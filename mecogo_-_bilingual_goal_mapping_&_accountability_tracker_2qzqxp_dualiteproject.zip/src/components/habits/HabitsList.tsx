import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Plus, Repeat, Flame, Check } from 'lucide-react';
import { Habit } from '../../types';
import { faker } from '@faker-js/faker';

interface HabitsListProps {
  onCreateHabit: () => void;
}

const HabitsList: React.FC<HabitsListProps> = ({ onCreateHabit }) => {
  const { t } = useTranslation();

  // Generate sample habits
  const habits: Habit[] = Array.from({ length: 6 }, (_, i) => ({
    id: `habit-${i}`,
    userId: 'user-1',
    title: faker.lorem.words(2),
    frequency: faker.helpers.arrayElement(['daily', 'weekly', 'monthly']),
    streakCount: faker.number.int({ min: 0, max: 30 }),
    lastCompleted: faker.date.recent(),
    createdAt: faker.date.past()
  }));

  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case 'daily': return 'bg-green-100 text-green-800';
      case 'weekly': return 'bg-blue-100 text-blue-800';
      case 'monthly': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">{t('habits.myHabits')}</h1>
        <button
          onClick={onCreateHabit}
          className="flex items-center space-x-2 rtl:space-x-reverse bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>{t('habits.createHabit')}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {habits.map((habit, index) => (
          <motion.div
            key={habit.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                  <Repeat className="w-5 h-5 text-primary-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{habit.title}</h3>
                  <span className={`inline-block px-2 py-1 text-xs rounded-full ${getFrequencyColor(habit.frequency)}`}>
                    {t(`habits.${habit.frequency}`)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Flame className="w-4 h-4 text-orange-500" />
                <span className="text-sm text-gray-600">
                  {habit.streakCount} {t('common.days')}
                </span>
              </div>
              <button className="w-8 h-8 bg-green-100 hover:bg-green-200 rounded-full flex items-center justify-center transition-colors">
                <Check className="w-4 h-4 text-green-600" />
              </button>
            </div>

            <div className="text-xs text-gray-500">
              {t('habits.currentStreak')}: {habit.streakCount} {t('common.days')}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default HabitsList;
