import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AnimatePresence, motion } from 'framer-motion';
import { User } from '../../types';
import { X, Send } from 'lucide-react';

interface MessageClientModalProps {
    isOpen: boolean;
    onClose: () => void;
    client: User;
}

const MessageClientModal: React.FC<MessageClientModalProps> = ({ isOpen, onClose, client }) => {
    const { t } = useTranslation();
    const [message, setMessage] = useState('');

    const handleSend = () => {
        if (message.trim()) {
            console.log(`Sending message to ${client.name}: ${message}`);
            onClose();
            setMessage('');
        }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.9, opacity: 0 }}
                        className="bg-white rounded-2xl p-6 w-full max-w-lg"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xl font-bold text-gray-900">{t('coach.sendMessageTo', { name: client.name })}</h2>
                            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                                <X className="w-6 h-6" />
                            </button>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1 rtl:text-right">{t('coach.message')}</label>
                                <textarea 
                                    rows={4} 
                                    className="w-full p-2 border rounded-lg rtl:text-right" 
                                    placeholder={`Hi ${client.name}...`}
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                ></textarea>
                            </div>
                            <div className="flex justify-end">
                                <button 
                                    onClick={handleSend}
                                    className="bg-primary-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 rtl:space-x-reverse"
                                >
                                    <Send className="w-4 h-4" />
                                    <span>{t('chat.send')}</span>
                                </button>
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default MessageClientModal;
