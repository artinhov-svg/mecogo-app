import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AnimatePresence, motion } from 'framer-motion';
import { User } from '../../types';
import { X } from 'lucide-react';

interface CreateGoalForClientModalProps {
    isOpen: boolean;
    onClose: () => void;
    client: User;
}

const CreateGoalForClientModal: React.FC<CreateGoalForClientModalProps> = ({ isOpen, onClose, client }) => {
    const { t } = useTranslation();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');

    const handleCreate = () => {
        if (title.trim()) {
            console.log(`Creating goal for ${client.name}: ${title}`);
            onClose();
            setTitle('');
            setDescription('');
        }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.9, opacity: 0 }}
                        className="bg-white rounded-2xl p-6 w-full max-w-lg"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xl font-bold text-gray-900">{t('coach.createNewGoalFor', { name: client.name })}</h2>
                            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                                <X className="w-6 h-6" />
                            </button>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1 rtl:text-right">{t('goals.goalTitle')}</label>
                                <input 
                                    type="text" 
                                    className="w-full p-2 border rounded-lg rtl:text-right"
                                    value={title}
                                    onChange={(e) => setTitle(e.target.value)}
                                />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1 rtl:text-right">{t('goals.goalDescription')}</label>
                                <textarea 
                                    rows={3} 
                                    className="w-full p-2 border rounded-lg rtl:text-right"
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                ></textarea>
                            </div>
                            <div className="flex justify-end space-x-2 rtl:space-x-reverse">
                                <button onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg">{t('common.cancel')}</button>
                                <button onClick={handleCreate} className="bg-primary-600 text-white px-4 py-2 rounded-lg">{t('common.create')}</button>
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default CreateGoalForClientModal;
