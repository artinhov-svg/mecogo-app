import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChecklistItem } from '../../types';
import { Plus, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ChecklistProps {
  initialItems: ChecklistItem[];
}

const Checklist: React.FC<ChecklistProps> = ({ initialItems }) => {
  const { t } = useTranslation();
  const [items, setItems] = useState<ChecklistItem[]>(initialItems);
  const [newItemText, setNewItemText] = useState('');

  const handleAddItem = () => {
    if (newItemText.trim()) {
      const newItem: ChecklistItem = {
        id: `item-${Date.now()}`,
        text: newItemText,
        isCompleted: false,
      };
      setItems([...items, newItem]);
      setNewItemText('');
    }
  };

  const toggleItem = (id: string) => {
    setItems(items.map(item => item.id === id ? { ...item, isCompleted: !item.isCompleted } : item));
  };

  const deleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-3">{t('goals.checklist')}</h3>
      <div className="space-y-3">
        <AnimatePresence>
          {items.map(item => (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex items-center justify-between bg-gray-50 p-3 rounded-lg"
            >
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={item.isCompleted}
                  onChange={() => toggleItem(item.id)}
                  className="h-5 w-5 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className={`ml-3 rtl:mr-3 text-sm ${item.isCompleted ? 'text-gray-500 line-through' : 'text-gray-800'}`}>
                  {item.text}
                </span>
              </div>
              <button onClick={() => deleteItem(item.id)} className="text-gray-400 hover:text-red-500">
                <Trash2 className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      <div className="mt-4 flex space-x-2 rtl:space-x-reverse">
        <input
          type="text"
          value={newItemText}
          onChange={(e) => setNewItemText(e.target.value)}
          placeholder={t('goals.addChecklistItem')}
          className="flex-grow px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        />
        <button
          onClick={handleAddItem}
          className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 flex items-center"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default Checklist;
