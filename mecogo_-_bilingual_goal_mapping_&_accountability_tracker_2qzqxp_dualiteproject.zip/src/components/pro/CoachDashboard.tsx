import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { faker } from '@faker-js/faker';
import { User as UserType } from '../../types';
import { Search, Plus, Eye, MessageSquare, Target, Calendar } from 'lucide-react';
import MessageClientModal from '../modals/MessageClientModal';
import CreateGoalForClientModal from '../modals/CreateGoalForClientModal';
import ScheduleMeetingModal from '../modals/ScheduleMeetingModal';

interface CoachDashboardProps {
    onImpersonate: (user: UserType) => void;
}

type ModalType = 'message' | 'goal' | 'meeting' | null;

const CoachDashboard: React.FC<CoachDashboardProps> = ({ onImpersonate }) => {
    const { t } = useTranslation();
    const [activeModal, setActiveModal] = useState<ModalType>(null);
    const [selectedClient, setSelectedClient] = useState<UserType | null>(null);

    const clients: UserType[] = Array.from({ length: 8 }, (_, i) => ({
        id: faker.string.uuid(),
        name: faker.person.fullName(),
        email: faker.internet.email(),
        avatarUrl: `https://i.pravatar.cc/150?u=client${i}`,
        role: 'client',
        createdAt: faker.date.past(),
        language: 'en'
    }));

    const clientProgress = clients.map(c => ({...c, progress: faker.number.int({ min: 30, max: 90 })}));

    const openModal = (modal: ModalType, client: UserType) => {
        setSelectedClient(client);
        setActiveModal(modal);
    };

    const closeModal = () => {
        setSelectedClient(null);
        setActiveModal(null);
    };

    return (
        <>
            <div className="p-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-6">{t('coach.myClients')}</h1>
                
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-6">
                        <div className="relative">
                            <Search className="absolute left-3 rtl:right-3 rtl:left-auto top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input type="text" placeholder={`${t('common.search')}...`} className="pl-9 rtl:pr-9 rtl:pl-3 pr-3 py-2 border rounded-lg w-64" />
                        </div>
                        <button className="bg-primary-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 rtl:space-x-reverse">
                            <Plus className="w-4 h-4" />
                            <span>{t('coach.addClient')}</span>
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {clientProgress.map(client => (
                            <div key={client.id} className="border rounded-xl p-4 flex flex-col justify-between hover:shadow-lg transition-shadow">
                                <div className="text-center">
                                    <img src={client.avatarUrl} alt={client.name} className="w-20 h-20 rounded-full mx-auto mb-4" />
                                    <h3 className="font-semibold text-gray-800">{client.name}</h3>
                                    <p className="text-sm text-gray-500 mb-4">{client.email}</p>
                                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                                        <div className="bg-primary-600 h-2.5 rounded-full" style={{ width: `${client.progress}%` }}></div>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">{client.progress}% {t('goals.progress')}</p>
                                </div>
                                <div className="mt-4 pt-4 border-t flex justify-around">
                                    <button onClick={() => onImpersonate(client)} className="p-2 text-gray-500 hover:text-primary-600 rounded-full hover:bg-primary-50" title={t('coach.viewAsClient') as string}><Eye className="w-5 h-5" /></button>
                                    <button onClick={() => openModal('message', client)} className="p-2 text-gray-500 hover:text-blue-600 rounded-full hover:bg-blue-50" title={t('coach.sendMessage') as string}><MessageSquare className="w-5 h-5" /></button>
                                    <button onClick={() => openModal('goal', client)} className="p-2 text-gray-500 hover:text-green-600 rounded-full hover:bg-green-50" title={t('coach.createGoal') as string}><Target className="w-5 h-5" /></button>
                                    <button onClick={() => openModal('meeting', client)} className="p-2 text-gray-500 hover:text-purple-600 rounded-full hover:bg-purple-50" title={t('coach.scheduleMeeting') as string}><Calendar className="w-5 h-5" /></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {selectedClient && (
                <>
                    <MessageClientModal isOpen={activeModal === 'message'} onClose={closeModal} client={selectedClient} />
                    <CreateGoalForClientModal isOpen={activeModal === 'goal'} onClose={closeModal} client={selectedClient} />
                    <ScheduleMeetingModal isOpen={activeModal === 'meeting'} onClose={closeModal} client={selectedClient} />
                </>
            )}
        </>
    );
};

export default CoachDashboard;
