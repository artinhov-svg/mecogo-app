import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { faker } from '@faker-js/faker';
import { ChatMessage, User } from '../../types';
import { Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import UpgradeModal from './UpgradeModal';

interface GroupChatPageProps {
    user: User;
}

const GroupChatPage: React.FC<GroupChatPageProps> = ({ user }) => {
    const { goalId } = useParams();
    const { t } = useTranslation();
    const navigate = useNavigate();
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [isUpgradeModalOpen, setUpgradeModalOpen] = useState(false);
    const chatEndRef = useRef<HTMLDivElement>(null);

    // Mock goal title and initial messages
    const goalTitle = "Learn a New Language";

    useEffect(() => {
        // Guard against user being undefined during render cycles.
        if (!user) return;

        if (!user.isPro) {
            setUpgradeModalOpen(true);
            return;
        }

        const initialMessages: ChatMessage[] = Array.from({ length: 10 }, () => {
            const userId = faker.string.uuid();
            return {
                id: faker.string.uuid(),
                userId: userId,
                userName: faker.person.firstName(),
                avatarUrl: `https://i.pravatar.cc/150?u=${userId}`,
                text: faker.lorem.sentence(),
                timestamp: faker.date.recent({ days: 1 }),
            };
        });
        setMessages(initialMessages);
    }, [user]); // Depend on the user object itself.

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim()) {
            const message: ChatMessage = {
                id: faker.string.uuid(),
                userId: user.id,
                userName: 'You',
                avatarUrl: user.avatarUrl || `https://i.pravatar.cc/150?u=${user.id}`,
                text: newMessage,
                timestamp: new Date(),
            };
            setMessages([...messages, message]);
            setNewMessage('');
        }
    };

    // Add a top-level guard to prevent rendering if the user object is not yet available.
    if (!user) {
        return null; // Or return a loading spinner
    }

    if (!user.isPro) {
        return <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => { setUpgradeModalOpen(false); navigate(-1); }} />;
    }

    return (
        <div className="p-6 h-full flex flex-col">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">{t('chat.groupChatFor', { goalTitle })}</h1>
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 flex-grow flex flex-col">
                <div className="flex-grow p-6 overflow-y-auto space-y-4">
                    <AnimatePresence>
                        {messages.map((msg) => (
                            <motion.div
                                key={msg.id}
                                layout
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0 }}
                                className={`flex items-start gap-3 ${msg.userId === user.id ? 'flex-row-reverse' : ''}`}
                            >
                                <img src={msg.avatarUrl} alt={msg.userName} className="w-10 h-10 rounded-full" />
                                <div className={`p-3 rounded-lg max-w-xs md:max-w-md ${msg.userId === user.id ? 'bg-primary-500 text-white' : 'bg-gray-100 text-gray-800'}`}>
                                    <p className="font-semibold text-sm">{msg.userName}</p>
                                    <p>{msg.text}</p>
                                    <p className={`text-xs mt-1 ${msg.userId === user.id ? 'text-blue-200' : 'text-gray-500'}`}>{new Date(msg.timestamp).toLocaleTimeString()}</p>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                    <div ref={chatEndRef} />
                </div>
                <div className="p-4 border-t">
                    <form onSubmit={handleSendMessage} className="flex items-center space-x-2 rtl:space-x-reverse">
                        <input
                            type="text"
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            placeholder={t('chat.typeMessage')}
                            className="flex-grow p-3 border rounded-lg focus:ring-2 focus:ring-primary-500 rtl:text-right"
                        />
                        <button type="submit" className="bg-primary-600 text-white p-3 rounded-lg hover:bg-primary-700">
                            <Send className="w-5 h-5" />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default GroupChatPage;
