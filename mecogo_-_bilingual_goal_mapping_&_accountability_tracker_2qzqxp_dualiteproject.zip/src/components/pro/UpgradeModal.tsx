import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star } from 'lucide-react';
import { ViralLogo } from '../ui/Logo';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: 50, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 50, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="bg-white rounded-2xl p-8 w-full max-w-md text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-4 flex justify-center">
                <ViralLogo size="md" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('pro.upgradeTitle')}</h2>
            <p className="text-gray-600 mb-6">{t('pro.upgradeMessage')}</p>
            
            <button 
              className="w-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold py-3 rounded-lg flex items-center justify-center space-x-2 hover:shadow-lg hover:scale-105 transition-all"
              onClick={onClose} // In a real app, this would lead to a pricing page
            >
              <Star className="w-5 h-5" />
              <span>{t('pro.upgradeButton')}</span>
            </button>

            <button onClick={onClose} className="mt-4 text-sm text-gray-500 hover:text-gray-700">
              {t('common.close')}
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default UpgradeModal;
