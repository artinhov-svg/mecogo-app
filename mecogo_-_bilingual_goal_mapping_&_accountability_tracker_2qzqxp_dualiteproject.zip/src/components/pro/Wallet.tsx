import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Wallet as WalletIcon, DollarSign, Shield, Info } from 'lucide-react';

const Wallet: React.FC = () => {
  const { t } = useTranslation();
  const [balance] = useState(150.75);
  const [staked, setStaked] = useState(50.00);
  const [penaltyEnabled, setPenaltyEnabled] = useState(true);

  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-4">{t('profile.wallet')}</h2>
      <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Balances */}
          <div className="space-y-4">
            <div className="flex items-center">
              <WalletIcon className="w-6 h-6 text-primary-600 mr-3 rtl:ml-3" />
              <h3 className="text-lg font-semibold text-gray-800">{t('profile.balance')}</h3>
            </div>
            <p className="text-4xl font-bold text-gray-900">${balance.toFixed(2)}</p>
            <div className="flex items-center text-green-600">
              <DollarSign className="w-5 h-5 mr-2 rtl:ml-2" />
              <span className="text-sm font-medium">{t('profile.stakedAmount')}: ${staked.toFixed(2)}</span>
            </div>
            <div className="flex space-x-2 rtl:space-x-reverse pt-2">
              <button className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700">{t('profile.stake')}</button>
              <button className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg text-sm font-medium hover:bg-gray-300">{t('profile.unstake')}</button>
            </div>
          </div>

          {/* Penalty System */}
          <div className="space-y-4">
            <div className="flex items-center">
              <Shield className="w-6 h-6 text-red-600 mr-3 rtl:ml-3" />
              <h3 className="text-lg font-semibold text-gray-800">{t('profile.penaltySystem')}</h3>
            </div>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 text-yellow-800 text-sm">
              <div className="flex">
                <Info className="w-5 h-5 mr-2 rtl:ml-2" />
                <p>{t('profile.penaltyWarning')}</p>
              </div>
            </div>
            <div className="flex items-center justify-between pt-2">
              <span className="font-medium text-gray-700">{t('profile.enablePenalty')}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={penaltyEnabled} onChange={() => setPenaltyEnabled(!penaltyEnabled)} className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-primary-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Wallet;
