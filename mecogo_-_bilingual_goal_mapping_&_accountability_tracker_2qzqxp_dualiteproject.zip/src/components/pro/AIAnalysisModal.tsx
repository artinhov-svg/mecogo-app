import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { X, BrainCircuit, BarChart2, CheckCircle } from 'lucide-react';
import { faker } from '@faker-js/faker';

interface AIAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AIAnalysisModal: React.FC<AIAnalysisModalProps> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-2xl p-8 w-full max-w-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <BrainCircuit className="w-6 h-6 text-primary-600" />
                <h2 className="text-xl font-bold text-gray-900">{t('dashboard.aiAnalysisTitle')}</h2>
              </div>
              <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <p className="text-gray-600 mb-6">{t('dashboard.aiAnalysisDescription')}</p>

            <div className="space-y-6 text-gray-700">
              <div>
                <h3 className="font-semibold text-lg mb-2 flex items-center"><BarChart2 className="w-5 h-5 mr-2 rtl:ml-2 text-secondary-500"/>{t('dashboard.aiAnalysisResult')}</h3>
                <p>{faker.lorem.paragraph()}</p>
              </div>
               <div>
                <h3 className="font-semibold text-lg mb-2 flex items-center"><CheckCircle className="w-5 h-5 mr-2 rtl:ml-2 text-green-500"/>{t('dashboard.aiAnalysisRecommendation')}</h3>
                <p>{faker.lorem.paragraph()}</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AIAnalysisModal;
