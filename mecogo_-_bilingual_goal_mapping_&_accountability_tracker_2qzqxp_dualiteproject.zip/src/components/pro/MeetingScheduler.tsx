import React from 'react';
import { useTranslation } from 'react-i18next';
import { Calendar, Video, Clock } from 'lucide-react';

const MeetingScheduler: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-4">{t('profile.meetings')}</h2>
      <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-800">Upcoming Meetings</h3>
          <button className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 flex items-center space-x-2 rtl:space-x-reverse">
            <Calendar className="w-4 h-4" />
            <span>{t('profile.scheduleMeeting')}</span>
          </button>
        </div>
        
        <div className="space-y-4">
          {/* Mock meeting */}
          <div className="p-4 border rounded-lg flex items-center justify-between">
            <div>
              <p className="font-semibold text-gray-800">Weekly Sync with Coach</p>
              <div className="flex items-center space-x-4 rtl:space-x-reverse text-sm text-gray-500 mt-1">
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>Tomorrow</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>10:00 AM</span>
                </div>
              </div>
            </div>
            <a href="#" className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium flex items-center space-x-2 rtl:space-x-reverse hover:bg-green-200">
              <Video className="w-4 h-4" />
              <span>Join Meet</span>
            </a>
          </div>
          
          <div className="text-center text-gray-500 py-4">
            <p>{t('common.noData')} for other meetings.</p>
            <button className="mt-2 text-primary-600 font-medium hover:underline">
              {t('profile.connectGoogleCalendar')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MeetingScheduler;
