import React from 'react';
import { useTranslation } from 'react-i18next';
import { CheckCircle, Target, Repeat } from 'lucide-react';
import { faker } from '@faker-js/faker';

const RecentActivity: React.FC = () => {
  const { t } = useTranslation();

  // Generate sample activities
  const activities = Array.from({ length: 5 }, (_, i) => {
    const type = faker.helpers.arrayElement(['goal', 'task', 'habit']);
    return {
      id: i,
      type,
      title: type === 'goal' 
        ? faker.lorem.words(3)
        : type === 'task'
        ? faker.lorem.words(2)
        : faker.lorem.words(2),
      time: faker.date.recent({ days: 1 }).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      icon: type === 'goal' ? Target : type === 'task' ? CheckCircle : Repeat
    };
  });

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        {t('dashboard.recentActivity')}
      </h3>
      
      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center">
                  <Icon className="w-4 h-4 text-primary-600" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {activity.title}
                </p>
                <p className="text-xs text-gray-500">{activity.time}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RecentActivity;
