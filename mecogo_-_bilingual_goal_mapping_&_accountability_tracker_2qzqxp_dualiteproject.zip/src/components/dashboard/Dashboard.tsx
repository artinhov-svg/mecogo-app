import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Target, CheckCircle, Flame, TrendingUp, BrainCircuit } from 'lucide-react';
import { DashboardStats } from '../../types';
import StatsCard from './StatsCard';
import ProgressChart from './ProgressChart';
import RecentActivity from './RecentActivity';
import AIAnalysisModal from '../pro/AIAnalysisModal';

interface DashboardProps {
  stats: DashboardStats;
  userName: string;
}

const Dashboard: React.FC<DashboardProps> = ({ stats, userName }) => {
  const { t } = useTranslation();
  const [isAiModalOpen, setAiModalOpen] = useState(false);

  const statsCards = [
    { title: t('dashboard.activeGoals'), value: stats.activeGoals.toString(), icon: Target, color: 'primary' },
    { title: t('dashboard.completedTasks'), value: stats.completedTasks.toString(), icon: CheckCircle, color: 'green' },
    { title: t('dashboard.habitStreak'), value: `${stats.habitStreak} ${t('common.days')}`, icon: Flame, color: 'orange' },
    { title: t('dashboard.weeklyProgress'), value: `${stats.weeklyProgress}%`, icon: TrendingUp, color: 'purple' }
  ];

  return (
    <div className="p-6 space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('dashboard.welcome')}, {userName}!</h1>
          <p className="text-gray-600">{t('dashboard.todaysProgress')}</p>
        </div>
        <button
          onClick={() => setAiModalOpen(true)}
          className="flex items-center space-x-2 rtl:space-x-reverse bg-secondary-500 text-white px-4 py-2 rounded-lg hover:bg-secondary-600 transition-colors"
        >
          <BrainCircuit className="w-5 h-5" />
          <span>{t('dashboard.aiAnalysis')}</span>
        </button>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((stat, index) => (
          <motion.div key={stat.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
            <StatsCard {...stat} />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
          <ProgressChart />
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}>
          <RecentActivity />
        </motion.div>
      </div>
      
      <AIAnalysisModal isOpen={isAiModalOpen} onClose={() => setAiModalOpen(false)} />
    </div>
  );
};

export default Dashboard;
