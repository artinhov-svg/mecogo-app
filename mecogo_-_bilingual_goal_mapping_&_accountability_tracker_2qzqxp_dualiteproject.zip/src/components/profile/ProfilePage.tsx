import React from 'react';
import { useTranslation } from 'react-i18next';
import { User } from '../../types';
import Wallet from '../pro/Wallet';
import MeetingScheduler from '../pro/MeetingScheduler';
import AvatarUpload from '../ui/AvatarUpload';
import { Clipboard, Check } from 'lucide-react';

const ProfilePage: React.FC<{ user: User }> = ({ user }) => {
  const { t } = useTranslation();
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    if (user.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getStatusPill = (status: User['coachStatus']) => {
    switch (status) {
      case 'pending':
        return <span className="px-3 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">{t('profile.statusPending')}</span>;
      case 'active':
        return <span className="px-3 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">{t('profile.statusActive')}</span>;
      case 'certified':
        return <span className="px-3 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">{t('profile.statusCertified')}</span>;
      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-6">{t('nav.profile')}</h1>
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            <AvatarUpload avatarUrl={user.avatarUrl} onUpload={() => {}} />
            <div className="flex-grow w-full">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('auth.fullName')}</label>
                  <input type="text" value={user.name} className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" readOnly />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">{t('auth.email')}</label>
                  <input type="email" value={user.email} className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" readOnly />
                </div>
                {user.role === 'coach' && user.referralCode && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t('profile.referralCode')}</label>
                    <div className="relative">
                      <input type="text" value={user.referralCode} className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 font-mono" readOnly />
                      <button onClick={handleCopy} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-gray-200 hover:bg-gray-300 rounded">
                        {copied ? <Check className="w-4 h-4 text-green-600" /> : <Clipboard className="w-4 h-4 text-gray-600" />}
                      </button>
                    </div>
                  </div>
                )}
                {user.role === 'coach' && user.coachStatus && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{t('profile.coachStatus')}</label>
                    <div className="w-full px-3 py-2 flex items-center">
                      {getStatusPill(user.coachStatus)}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Wallet />
      <MeetingScheduler />
    </div>
  );
};

export default ProfilePage;
