import React from 'react';
import { useTranslation } from 'react-i18next';
import { Camera } from 'lucide-react';

interface AvatarUploadProps {
  avatarUrl?: string;
  onUpload: (file: File) => void;
}

const AvatarUpload: React.FC<AvatarUploadProps> = ({ avatarUrl, onUpload }) => {
  const { t } = useTranslation();
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onUpload(file);
      // In a real app, you would upload the file and get a new URL.
      // For this demo, we'll just log it.
      console.log('File selected:', file.name);
    }
  };

  return (
    <div className="relative w-32 h-32 flex-shrink-0">
      <img
        src={avatarUrl || `https://i.pravatar.cc/150?u=default`}
        alt="Profile"
        className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-md"
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="absolute bottom-1 right-1 w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center text-white hover:bg-primary-700 transition-all duration-300 transform hover:scale-110"
        title={t('profile.uploadAvatar')}
      >
        <Camera className="w-5 h-5" />
      </button>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg"
      />
    </div>
  );
};

export default AvatarUpload;
