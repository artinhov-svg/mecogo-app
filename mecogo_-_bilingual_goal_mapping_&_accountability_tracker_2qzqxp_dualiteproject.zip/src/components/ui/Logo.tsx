import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

// New Viral Logo
const ViralLogo: React.FC<LogoProps> = ({ size = 'md', className = '' }) => {
    const sizes = {
        sm: 'w-8 h-8',
        md: 'w-12 h-12',
        lg: 'w-16 h-16',
    };

    return (
        <div className={`${sizes[size]} ${className}`}>
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g>
                    <path d="M50 0L93.3013 25V75L50 100L6.69873 75V25L50 0Z" fill="url(#paint0_linear_viral_logo)"/>
                    <path d="M50 26L33 36V56L50 66L67 56V36L50 26Z" fill="white" fillOpacity="0.2"/>
                    <path d="M50 30L36 38.6603V55.9808L50 64.641L64 55.9808V38.6603L50 30Z" stroke="white" strokeWidth="2"/>
                    <path d="M41 54L50 45L59 54" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M50 45V60" stroke="white" strokeWidth="4" strokeLinecap="round"/>
                </g>
                <defs>
                    <linearGradient id="paint0_linear_viral_logo" x1="50" y1="0" x2="50" y2="100" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#FBBF24"/>
                        <stop offset="1" stopColor="#F97316"/>
                    </linearGradient>
                </defs>
            </svg>
        </div>
    );
};

export default ViralLogo;
export { ViralLogo };
