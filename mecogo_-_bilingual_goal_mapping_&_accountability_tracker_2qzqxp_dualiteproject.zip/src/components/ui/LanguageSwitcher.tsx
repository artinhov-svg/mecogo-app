import React from 'react';
import { Globe } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';

const LanguageSwitcher: React.FC = () => {
  const { currentLanguage, changeLanguage } = useLanguage();

  return (
    <div className="relative">
      <button
        onClick={() => changeLanguage(currentLanguage === 'en' ? 'fa' : 'en')}
        className="flex items-center space-x-2 rtl:space-x-reverse px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
      >
        <Globe className="w-4 h-4" />
        <span className="text-sm font-medium">
          {currentLanguage === 'en' ? 'فارسی' : 'English'}
        </span>
      </button>
    </div>
  );
};

export default LanguageSwitcher;
