import React from 'react';
import { useTranslation } from 'react-i18next';
import { Info, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import { isDemoMode } from '../../config/demo';

const DemoBanner: React.FC = () => {
  const { t } = useTranslation();

  if (!isDemoMode()) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Info className="w-4 h-4" />
          <span className="text-sm font-medium">
            🎯 You're using MeCOGO Demo Mode - All features available with sample data
          </span>
        </div>
        <div className="flex items-center space-x-4 rtl:space-x-reverse text-sm">
          <span>Demo User: demo@mecogo.app</span>
          <a 
            href="https://supabase.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-1 rtl:space-x-reverse hover:underline"
          >
            <span>Connect Database</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </motion.div>
  );
};

export default DemoBanner;
