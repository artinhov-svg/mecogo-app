import React from 'react';
import { useTranslation } from 'react-i18next';
import { UserX, User } from 'lucide-react';
import { User as UserType } from '../../types';

interface ImpersonationBannerProps {
  impersonatedUser: UserType;
  onStopImpersonating: () => void;
}

const ImpersonationBanner: React.FC<ImpersonationBannerProps> = ({ impersonatedUser, onStopImpersonating }) => {
  const { t } = useTranslation();

  return (
    <div className="bg-yellow-400 text-yellow-900 px-4 py-2 text-center text-sm font-semibold z-50 relative">
      <div className="max-w-7xl mx-auto flex items-center justify-center space-x-4">
        <User className="w-5 h-5" />
        <span>
          {t('admin.impersonationBanner', { name: impersonatedUser.name })}
        </span>
        <button
          onClick={onStopImpersonating}
          className="flex items-center space-x-2 bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md"
        >
          <UserX className="w-4 h-4" />
          <span>{t('admin.returnToAdmin')}</span>
        </button>
      </div>
    </div>
  );
};

export default ImpersonationBanner;
