import React from 'react';
import { useTranslation } from 'react-i18next';
import { Star } from 'lucide-react';

const ProFeatureBadge: React.FC = () => {
    const { t } = useTranslation();

    return (
        <div className="ml-2 rtl:mr-2 inline-flex items-center bg-accent text-white text-xs font-bold px-2 py-1 rounded-md shadow">
            <Star className="w-3 h-3 mr-1 rtl:ml-1 fill-white" />
            <span>{t('common.proFeature')}</span>
        </div>
    );
};

export default ProFeatureBadge;
