import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Mail, Lock, User, Briefcase, Shield } from 'lucide-react';
import { User as UserType } from '../../types';
import { ViralLogo } from '../ui/Logo';
import { useLanguage } from '../../hooks/useLanguage';

interface LoginFormProps {
  onLogin: (email: string, password: string, role: UserType['role']) => void;
  onSwitchToRegister: () => void;
}

const roles: { id: UserType['role']; name: string; icon: React.ElementType }[] = [
  { id: 'client', name: 'auth.client', icon: User },
  { id: 'coach', name: 'auth.coach', icon: Briefcase },
  { id: 'owner', name: 'auth.admin', icon: Shield },
];

const LoginForm: React.FC<LoginFormProps> = ({ onLogin, onSwitchToRegister }) => {
  const { t } = useTranslation();
  const { isRTL } = useLanguage();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserType['role']>('client');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(email, password, selectedRole);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-md mx-auto"
    >
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="mx-auto mb-4 flex justify-center">
            <ViralLogo size="lg" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">MeCOGO</h2>
          <p className="text-gray-600">{t('auth.loginToContinue')}</p>
        </div>

        <div className="mb-6">
          <div className="grid grid-cols-3 gap-2 bg-gray-100 p-1 rounded-lg">
            {roles.map((role) => {
              const Icon = role.icon;
              return (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role.id)}
                  className={`relative flex items-center justify-center space-x-2 rtl:space-x-reverse w-full px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    selectedRole === role.id
                      ? 'text-primary-700'
                      : 'text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {selectedRole === role.id && (
                    <motion.div
                      layoutId="login-role-bubble"
                      className="absolute inset-0 bg-white rounded-md shadow-sm"
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                    />
                  )}
                  <Icon className="relative w-4 h-4" />
                  <span className="relative">{t(role.name)}</span>
                </button>
              );
            })}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t('auth.email')}
            </label>
            <div className="relative">
              <Mail className={`absolute top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 ${isRTL ? 'right-3' : 'left-3'}`} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent py-3 ${isRTL ? 'pr-10 pl-3 text-right' : 'pl-10 pr-3 text-left'}`}
                placeholder="your@email.com"
                required
              />
            </div>
          </div>

          <div>
            <label className={`block text-sm font-medium text-gray-700 mb-2 ${isRTL ? 'text-right' : 'text-left'}`}>
              {t('auth.password')}
            </label>
            <div className="relative">
              <Lock className={`absolute top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 ${isRTL ? 'right-3' : 'left-3'}`} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent py-3 ${isRTL ? 'pr-10 pl-3 text-right' : 'pl-10 pr-3 text-left'}`}
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-primary-600 text-white py-3 rounded-lg font-medium hover:bg-primary-700 transition-colors"
          >
            {t('auth.login')}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-600">
            {t('auth.dontHaveAccount')}{' '}
            <button
              onClick={onSwitchToRegister}
              className="text-primary-600 hover:text-primary-700 font-medium"
            >
              {t('auth.register')}
            </button>
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default LoginForm;
