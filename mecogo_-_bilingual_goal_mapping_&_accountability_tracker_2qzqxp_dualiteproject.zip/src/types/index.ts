export interface User {
  id: string;
  email: string;
  name: string;
  role: 'client' | 'coach' | 'owner';
  language: 'en' | 'fa';
  avatarUrl?: string;
  createdAt: Date;
  coachingType?: 'personal' | 'business';
  referralCode?: string; // For coaches
  coachStatus?: 'pending' | 'active' | 'certified'; // For coach lifecycle
  referredBy?: string; // For clients
  isPro?: boolean; // To identify premium users
}

export interface ChecklistItem {
  id: string;
  text: string;
  isCompleted: boolean;
}

export interface Goal {
  id: string;
  userId: string;
  title: string;
  description?: string;
  startDate: Date;
  endDate?: Date;
  status: 'active' | 'completed' | 'archived';
  progress: number;
  tasks: Task[];
  checklist?: ChecklistItem[];
  isBusinessGoal: boolean;
  kpis?: string[];
  createdAt: Date;
  createdBy: 'user' | 'coach';
}

export interface Task {
  id: string;
  goalId: string;
  title: string;
  description?: string;
  dueDate?: Date;
  isCompleted: boolean;
  createdAt: Date;
}

export interface Habit {
  id: string;
  userId: string;
  title: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  streakCount: number;
  lastCompleted?: Date;
  createdAt: Date;
}

export interface Wallet {
  userId: string;
  balance: number;
  stakedAmount: number;
  penaltyEnabled: boolean;
}

export interface Meeting {
  id: string;
  title: string;
  participants: string[]; // user emails
  startTime: Date;
  endTime: Date;
  googleMeetUrl?: string;
}

export interface DiscountCode {
  id: string;
  code: string;
  percentage: number;
  isActive: boolean;
  createdAt: Date;
}

export interface Referral {
  id: string;
  referrerName: string;
  referrerId: string;
  referredUserName: string;
  referredUserId: string;
  date: Date;
  status: 'pending' | 'completed';
  commissionEarned: number;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  avatarUrl: string;
  text: string;
  timestamp: Date;
}

export interface ProgressLog {
  id: string;
  userId: string;
  habitId?: string;
  taskId?: string;
  logDate: Date;
  status: 'completed' | 'missed';
}

export interface Badge {
  id:string;
  title: string;
  description: string;
  icon: string;
  earnedDate?: Date;
}

export interface DashboardStats {
  activeGoals: number;
  completedTasks: number;
  habitStreak: number;
  weeklyProgress: number;
}
