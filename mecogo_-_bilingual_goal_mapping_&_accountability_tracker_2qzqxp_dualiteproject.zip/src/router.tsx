import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { User } from './types';

// Layouts
import AppLayout from './components/layout/AppLayout';
import AdminLayout from './components/admin/AdminLayout';

// Pages
import Dashboard from './components/dashboard/Dashboard';
import GoalsList from './components/goals/GoalsList';
import HabitsList from './components/habits/HabitsList';
import ProfilePage from './components/profile/ProfilePage';
import GoalDetail from './components/goals/GoalDetail';
import CoachDashboard from './components/pro/CoachDashboard';
import GroupChatPage from './components/pro/GroupChatPage';
import AnalyticsPage from './pages/AnalyticsPage';

// Admin Pages
import AdminDashboard from './components/admin/AdminDashboard';
import DiscountCodeManager from './components/admin/DiscountCodeManager';
import PlatformSettings from './components/admin/PlatformSettings';
import FinancialSettings from './components/admin/FinancialSettings';
import AccountViewer from './components/admin/AccountViewer';
import ReferralSettings from './components/admin/ReferralSettings';
import PlatformManagement from './components/admin/PlatformManagement';

interface AppRouterProps {
  user: User;
  stats: any;
  onLogout: () => void;
  onImpersonate: (user: User) => void;
}

const ProtectedRoute: React.FC<{ user: User; role: User['role']; children: JSX.Element }> = ({ user, role, children }) => {
  if (user.role !== role) {
    return <Navigate to="/" replace />;
  }
  return children;
};

export const AppRouter: React.FC<AppRouterProps> = ({ user, stats, onLogout, onImpersonate }) => {
  if (user.role === 'owner') {
    return (
      <AdminLayout user={user} onLogout={onLogout}>
        <Routes>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/discounts" element={<DiscountCodeManager />} />
          <Route path="/admin/settings" element={<PlatformSettings />} />
          <Route path="/admin/financial-settings" element={<FinancialSettings />} />
          <Route path="/admin/referrals" element={<ReferralSettings />} />
          <Route path="/admin/users" element={<AccountViewer onImpersonate={onImpersonate} />} />
          <Route path="/admin/management" element={<PlatformManagement />} />
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </AdminLayout>
    );
  }

  return (
    <AppLayout user={user} onLogout={onLogout}>
      <Routes>
        <Route path="/" element={<Dashboard stats={stats} userName={user.name} />} />
        <Route path="/goals" element={<GoalsList user={user} />} />
        <Route path="/goals/:id" element={<GoalDetail user={user} />} />
        <Route path="/habits" element={<HabitsList onCreateHabit={() => {}} />} />
        <Route path="/analytics" element={<AnalyticsPage user={user} />} />
        <Route path="/profile" element={<ProfilePage user={user} />} />
        <Route path="/chat/:goalId" element={<GroupChatPage user={user} />} />
        {user.role === 'coach' && (
          <Route path="/coach/dashboard" element={<CoachDashboard onImpersonate={onImpersonate} />} />
        )}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppLayout>
  );
};
