import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { User } from '../types';
import { FileDown } from 'lucide-react';
import ProgressChart from '../components/dashboard/ProgressChart';
import ProFeatureBadge from '../components/ui/ProFeatureBadge';
import UpgradeModal from '../components/pro/UpgradeModal';
import { exportAnalyticsToPDF } from '../utils/pdfExporter';
import StatsCard from '../components/dashboard/StatsCard';
import { Target, CheckCircle, Flame, TrendingUp } from 'lucide-react';
import { faker } from '@faker-js/faker';

interface AnalyticsPageProps {
    user: User;
}

const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ user }) => {
    const { t } = useTranslation();
    const [isUpgradeModalOpen, setUpgradeModalOpen] = useState(false);

    const handleExportClick = () => {
        if (user.isPro) {
            exportAnalyticsToPDF(user.name, t);
        } else {
            setUpgradeModalOpen(true);
        }
    };
    
    const stats = {
        activeGoals: faker.number.int({ min: 1, max: 10 }),
        completedTasks: faker.number.int({ min: 10, max: 50 }),
        habitStreak: faker.number.int({ min: 0, max: 25 }),
        weeklyProgress: faker.number.int({ min: 40, max: 95 })
    };

    const statsCards = [
        { title: t('dashboard.activeGoals'), value: stats.activeGoals.toString(), icon: Target, color: 'primary' },
        { title: t('dashboard.completedTasks'), value: stats.completedTasks.toString(), icon: CheckCircle, color: 'green' },
        { title: t('dashboard.habitStreak'), value: `${stats.habitStreak} ${t('common.days')}`, icon: Flame, color: 'orange' },
        { title: t('dashboard.weeklyProgress'), value: `${stats.weeklyProgress}%`, icon: TrendingUp, color: 'purple' }
    ];

    return (
        <>
            <div className="p-6">
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 mb-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">{t('analytics.title')}</h1>
                            <p className="text-gray-500 mt-1">{t('analytics.description')}</p>
                        </div>
                        <div className="flex items-center space-x-2 rtl:space-x-reverse mt-4 sm:mt-0">
                            <button 
                                onClick={handleExportClick}
                                className="flex items-center space-x-2 rtl:space-x-reverse bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200"
                            >
                                <FileDown className="w-4 h-4" />
                                <span>{t('analytics.exportReport')}</span>
                                {!user.isPro && <ProFeatureBadge />}
                            </button>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    {statsCards.map((stat) => (
                        <StatsCard key={stat.title} {...stat} />
                    ))}
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <ProgressChart />
                    <ProgressChart />
                </div>
            </div>
            <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setUpgradeModalOpen(false)} />
        </>
    );
};

export default AnalyticsPage;
